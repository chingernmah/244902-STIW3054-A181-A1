/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.maven_asg1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
 import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
/**
 *
 * @author Personal
 */
public class Read {
    
    public static List<Info> readData(){
           final String url =
                   "https://ms.wikipedia.org/wiki/Malaysia";
          
       try {     
           List<Info> dt = new ArrayList<Info>();
           final Document document= Jsoup.connect(url).get();
           
       for (Element row : document.select("#mw-content-text > div > table:nth-child(148) > tbody > tr")){
        
              String th = row.select("th").text();
              String td = row.select("td").text();
                
                dt.add(new Info(th,td));
          
       } return dt;
       
        } catch (IOException ex) {
        }
        return null;
    }
    
}
