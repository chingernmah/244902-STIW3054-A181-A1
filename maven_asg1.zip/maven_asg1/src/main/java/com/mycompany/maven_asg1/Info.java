/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.maven_asg1;
/**
 *
 * @author Personal
 */
public class Info {
    private String th;
    private String td;
    
    public Info(){
        super();
    }
    
    public Info(String hd,String dt){
        super();
        this.th=hd;
        this.td=dt;
    }
    
    public void setHd(String hd){
        this.th=hd;
    }
    
    public String getHd(){
        return th;
    }
    
    public void setDt(String dt){
        this.td = dt;
    }
    public String getDt(){
        return td;
    }
    
}
