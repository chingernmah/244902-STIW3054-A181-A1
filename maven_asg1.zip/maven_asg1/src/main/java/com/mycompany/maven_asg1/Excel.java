/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.maven_asg1;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;



/**
 *
 * @author Personal
 */
public class Excel {
    public static void writeXLSFile() throws IOException {
		
        try{

		String sheetName = "Trivia";//name of sheet

                FileOutputStream fileOut;
            try (HSSFWorkbook wb = new HSSFWorkbook()) {
                HSSFSheet sheet = wb.createSheet(sheetName) ;
                //iterating r number of rows
                int a=0;
                for (Info i : Read.readData())
                {
                    
                    Row row=sheet.createRow(a);
                    Cell cl = row.createCell(0);
                    cl.setCellValue(i.getHd());
                    Cell c2 = row.createCell(1);
                    c2.setCellValue(i.getDt());
                    
                    a++;
                    
                }
                for (int j=0;j<2;j++){
                    sheet.autoSizeColumn(j);
                }
                //write this workbook to an Outputstream.
                fileOut = new FileOutputStream(new File("C:\\Users\\Personal\\Documents\\NetBeansProjects\\Trivia.xls"));
                //write this workbook to an Outputstream.
                wb.write(fileOut);
            }
            fileOut.close();
            System.out.println("Excel File create successfully!");
                 System.out.println("Excel file is at "+ fileOut);
        }catch (IOException e){
            System.out.println(e.getMessage());
        }
	}
    
}
